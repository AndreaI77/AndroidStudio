package edu.andreaivanova.myfavouritespets.model

class Pelaje(var id:Int, var nombre :String){

    override fun toString():String{
        return nombre
    }
}
