package edu.andreaivanova.myfavouritespets.model

data class Pet(var id:Int, var nombre:String, var latName:String, var image:String,
               var clase:Clase, var pelo:Pelaje, var rating:Float, var favorite:Int)
