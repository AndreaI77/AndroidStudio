package edu.andreaivanova.myfavouritespets.model

class Clase(var id :Int, var nombre :String) {

    override fun toString():String{
        return nombre
    }

}