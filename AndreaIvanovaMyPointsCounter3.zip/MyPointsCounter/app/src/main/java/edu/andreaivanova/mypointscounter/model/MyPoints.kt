package edu.andreaivanova.mypointscounter.model

data class MyPoints(var id:Int, var points:Int, var date:String, var hour:String)
